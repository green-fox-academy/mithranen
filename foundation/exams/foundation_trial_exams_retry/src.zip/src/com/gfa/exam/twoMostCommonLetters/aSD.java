package com.gfa.exam.twoMostCommonLetters;

import java.util.Arrays;

public class aSD {

  public static void main(String[] args) {
    String str = " Medve karma";

    char[] charsArray = str.trim().toCharArray();
    System.out.println((charsArray)); //bármilyen tömböt gy írhatsz Ki!!!
    System.out.println(Arrays.toString(charsArray)); //bármilyen tömböt gy írhatsz Ki!!!


  }

}
